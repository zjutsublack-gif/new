# License

Copyright (c) 2024-2026 AnyTry.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

## AnyTry API Service

The AnyTry API service (api.anytry.ai) is a separate proprietary service.
Use of the API requires a valid API key and is subject to the
[AnyTry Terms of Service](https://anytry.ai/terms.html).

The GPL license applies only to this WordPress plugin code, not to the
external API service.
