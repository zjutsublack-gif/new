<?php
/**
 * Product popup adapted from AnyTry 1.0.44.
 * Copyright (c) 2024-2026 AnyTry.
 * Licensed under GPLv2 or later.
 */
defined( 'ABSPATH' ) || exit;
?>
<div class="anytry-container">
	<button type="button" class="anytry-button anytry-open-modal anytry-btn-trigger--filled" data-anytry-open aria-haspopup="dialog" aria-controls="anytry-openai-dialog" disabled>
		<span class="anytry-button-text">Try On</span>
	</button>
</div>
<dialog id="anytry-openai-dialog" aria-labelledby="anytry-modal-heading">
	<div id="anytry-modal" class="anytry-modal-content">
		<button type="button" class="anytry-close" data-anytry-close aria-label="Close window">&times;</button>
		<h2 class="anytry-modal-title" id="anytry-modal-heading">Virtual fitting room</h2>
		<?php if ( ! self::can_use( $settings ) ) : ?>
			<p class="anytry-openai-login"><a href="<?php echo esc_url( wp_login_url( get_permalink( $product_for_popup->get_id() ) ) ); ?>">Sign in</a> to try on this product.</p>
		<?php else : ?>
			<div class="anytry-tabs" aria-label="Photo views">
				<button type="button" class="anytry-tab active" data-view="before" aria-pressed="true">Before</button>
				<button type="button" class="anytry-tab" data-view="after" aria-pressed="false" disabled>After</button>
			</div>
			<form class="anytry-openai-form" method="post" enctype="multipart/form-data" action="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>" data-mode="<?php echo $live ? 'live' : 'preview'; ?>">
				<input type="hidden" name="action" value="anytry_openai_edit">
				<input type="hidden" name="product_id" value="<?php echo esc_attr( $product_for_popup->get_id() ); ?>">
				<input type="hidden" name="provider" value="<?php echo esc_attr( $built_provider ); ?>">
				<?php wp_nonce_field( 'anytry_openai_edit', 'nonce', false ); ?>
				<div class="anytry-upload-area anytry-openai-panel" data-panel="before">
					<img data-preview hidden alt="Your selected photo">
					<div class="anytry-controls upload-controls">
						<input type="file" name="photo" class="anytry-openai-file" id="anytry-openai-file" accept="image/jpeg,image/png,image/webp" required>
						<label class="anytry-button" for="anytry-openai-file" data-photo-label>Choose photo</label>
					</div>
				</div>
				<div class="anytry-result-area anytry-openai-panel" data-panel="after" hidden>
					<img data-result alt="AI-generated try-on image">
					<a class="anytry-button anytry-btn-secondary" data-download download="try-on">Download image</a>
				</div>
				<div class="anytry-openai-actions" data-generate hidden>
					<?php if ( $live ) : ?>
						<label><input type="checkbox" name="consent" value="1" required> Send my photo to <?php echo esc_html( $provider_name ); ?> to generate this try-on.</label>
						<button class="anytry-button" type="submit" disabled>Generate try-on</button>
					<?php else : ?>
						<p>Photo preview. The store hasn’t connected an image provider yet.</p>
					<?php endif; ?>
				</div>
				<p class="anytry-openai-status" data-status role="status" aria-live="polite"></p>
			</form>
		<?php endif; ?>
	</div>
</dialog>
