=== AnyTry OpenAI for WooCommerce ===
Requires at least: 6.5
Requires PHP: 7.4
License: GPLv2 or later

An independent, streamlined fork of AnyTry 1.0.44 for WooCommerce product-page virtual try-on. Original AnyTry notices are included.

== Installation ==
1. Deactivate the original AnyTry plugin to avoid duplicate controls. Upload this ZIP under Plugins > Add New > Upload Plugin and activate it alongside WooCommerce.
2. Open WooCommerce > AnyTry OpenAI. The default image model is gpt-image-1-mini. Set another OpenAI model ID there if it supports /v1/images/edits with multiple input images.
3. Add an OpenAI API key from a project with API billing. Alternatively, set the ANYTRY_OPENAI_API_KEY constant in wp-config.php. A ChatGPT subscription does not include OpenAI API usage.
4. As an administrator, open an in-stock WooCommerce product page with a local media-library image. Open Try On and test with a JPG, PNG or WebP photo. Enable signed-in customer access after testing. The daily limit is 20 attempts per store, including failed provider requests.

== Preview and generation ==
Without a key, the browser displays the selected upload locally. The free preview displays the original photo. With a key and the user's consent, WordPress sends the photo and the product image to OpenAI over HTTPS. The plugin displays the returned image in the page and does not create a media-library item for the upload or result. Host and OpenAI processing and retention policies still apply. The image is an AI visualization and cannot determine actual fit.

Product images must be accessible as local WordPress uploads. Both images must be JPG, PNG or WebP, up to 5 MB each. Generation is synchronous and requires WordPress hosting that can keep a request open long enough for the OpenAI API. The integration focuses on product-page try-on and excludes AnyTry account, analytics, size-advisor, cart and listing features.
