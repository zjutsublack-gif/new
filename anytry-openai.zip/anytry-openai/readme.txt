=== AnyTry OpenAI for WooCommerce ===
Requires at least: 6.5
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPLv2 or later

A fork of AnyTry 1.0.44 with the original popup styles and Before/After layout, using OpenAI or Google Gemini for the image request.

== Installation and upgrade ==
1. Deactivate the original AnyTry plugin to avoid duplicate controls. Upload this ZIP under Plugins > Add New > Upload Plugin. If WordPress detects a previous AnyTry OpenAI version, choose Replace current with uploaded. Keep WooCommerce active.
2. Open WooCommerce > AnyTry OpenAI. Choose OpenAI or Google Gemini and enter the matching API key. The editable defaults are gpt-image-1-mini and gemini-2.5-flash-image. Both model options need image generation and two input images. Keys can also be configured via ANYTRY_OPENAI_API_KEY and ANYTRY_GEMINI_API_KEY in wp-config.php.
3. As an administrator, open a WooCommerce product page with a product photo. Click Try On, choose a local image, confirm provider sharing, and generate. Clear cached pages and assets after upgrading if the old widget appears.
4. Enable signed-in customer access in settings when ready. Signed-out visitors see a sign-in prompt when customer access is enabled. The store can make 20 attempts per UTC day, including failed provider requests.
5. For a product template that does not render classic WooCommerce hooks, add a Shortcode block with [anytry_openai] to the Single Product template.

== Preview and generation ==
Without a key, the Before tab displays your selected photo locally. Generation uses the active provider and requires a key with image-model access and sufficient quota or billing. When you consent, WordPress sends both photos to that provider. This plugin does not create a WordPress Media Library item for the upload or result. Downstream retention policies depend on your host and provider.

Images must be JPEG, PNG or WebP, up to 5 MB each. The product image can be a local attachment or a reachable HTTPS WordPress media attachment. Generation is synchronous and requires hosting that can keep the connection open until the provider responds. This fork includes product-page try-on. AnyTry account, analytics, and size-advisor services are outside its integration.
