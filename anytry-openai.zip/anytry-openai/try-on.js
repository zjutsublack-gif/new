(function () {
    'use strict';

    document.addEventListener('submit', async function (event) {
        const form = event.target;
        if (!form.matches('.anytry-openai-form')) return;
        event.preventDefault();

        const button = form.querySelector('button[type="submit"]');
        if (button.disabled) return;
        const input = form.elements.photo;
        const status = form.querySelector('[data-status]');
        const result = form.querySelector('[data-result]');

        if (result.src.startsWith('blob:')) URL.revokeObjectURL(result.src);
        result.removeAttribute('src');
        result.hidden = true;

        const photo = input.files[0];
        if (!photo || !['image/jpeg', 'image/png', 'image/webp'].includes(photo.type) || photo.size > 5242880) {
            status.textContent = 'Choose a JPG, PNG or WebP photo up to 5 MB.';
            return;
        }
        if (form.dataset.mode === 'preview') {
            result.src = URL.createObjectURL(photo);
            result.alt = 'Your uploaded photo';
            result.hidden = false;
            status.textContent = 'Photo preview';
            return;
        }

        button.disabled = true;
        status.textContent = 'Generating your try-on…';
        try {
            const variation = form.closest('.product')?.querySelector('.variations_form [name="variation_id"]');
            if (variation && !Number(variation.value)) throw new Error('Choose a product variation first.');
            const body = new FormData(form);
            if (variation) body.set('variation_id', variation.value);
            const response = await fetch(form.action, {method: 'POST', body, credentials: 'same-origin'});
            const data = await response.json();
            if (!response.ok || !data.success || !data.data.image) {
                throw new Error(data.data?.message || 'Unable to generate the try-on image.');
            }
            result.src = 'data:image/png;base64,' + data.data.image;
            result.alt = 'AI-generated virtual try-on';
            result.hidden = false;
            status.textContent = 'Your try-on image is ready.';
        } catch (error) {
            status.textContent = error instanceof SyntaxError ? 'The server returned an unexpected response. Refresh and try again.' : error.message;
        } finally {
            button.disabled = false;
        }
    });
    document.querySelectorAll('.anytry-openai-form button[type="submit"]').forEach(function (button) {
        button.disabled = false;
    });
})();
