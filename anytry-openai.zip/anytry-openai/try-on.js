(function () {
    'use strict';

    const dialog = document.getElementById('anytry-openai-dialog');
    const trigger = document.querySelector('[data-anytry-open]');
    if (!dialog || !trigger || typeof dialog.showModal !== 'function') return;
    document.body.append(dialog);
    trigger.disabled = false;
    trigger.addEventListener('click', () => dialog.showModal());
    dialog.querySelector('[data-anytry-close]').addEventListener('click', () => dialog.close());
    dialog.addEventListener('click', event => {
        if (event.target === dialog) dialog.close();
    });

    const form = dialog.querySelector('form');
    if (!form) return;
    const input = form.elements.photo;
    const status = form.querySelector('[data-status]');
    const preview = form.querySelector('[data-preview]');
    const result = form.querySelector('[data-result]');
    const button = form.querySelector('button[type="submit"]');
    const after = dialog.querySelector('[data-view="after"]');
    const actions = form.querySelector('[data-generate]');
    const download = form.querySelector('[data-download]');
    let previewUrl;
    let resultUrl;
    let photoVersion = 0;

    function show(view) {
        dialog.querySelectorAll('[data-view]').forEach(tab => {
            const selected = tab.dataset.view === view;
            tab.classList.toggle('active', selected);
            tab.setAttribute('aria-pressed', String(selected));
        });
        form.querySelectorAll('[data-panel]').forEach(panel => {
            panel.hidden = panel.dataset.panel !== view;
        });
        actions.hidden = view !== 'before' || preview.hidden;
    }

    dialog.querySelectorAll('[data-view]').forEach(tab => {
        tab.addEventListener('click', () => show(tab.dataset.view));
    });

    input.addEventListener('change', () => {
        photoVersion += 1;
        if (previewUrl) URL.revokeObjectURL(previewUrl);
        if (resultUrl) URL.revokeObjectURL(resultUrl);
        previewUrl = resultUrl = undefined;
        preview.hidden = true;
        preview.removeAttribute('src');
        result.removeAttribute('src');
        download.removeAttribute('href');
        after.disabled = true;
        status.textContent = '';
        const photo = input.files[0];
        if (photo && ['image/jpeg', 'image/png', 'image/webp'].includes(photo.type) && photo.size <= 5242880) {
            previewUrl = URL.createObjectURL(photo);
            preview.src = previewUrl;
            preview.hidden = false;
        } else if (photo) {
            input.value = '';
            status.textContent = 'Choose a JPG, PNG or WebP photo up to 5 MB.';
        }
        form.querySelector('[data-photo-label]').textContent = preview.hidden ? 'Choose photo' : 'Change photo';
        show('before');
    });

    if (!button) return;
    button.disabled = false;
    form.addEventListener('submit', async event => {
        event.preventDefault();
        if (button.disabled || preview.hidden || !form.reportValidity()) return;
        const version = photoVersion;
        button.disabled = true;
        status.textContent = 'Generating your try-on…';
        try {
            const variantForm = trigger.closest('.product')?.querySelector('.variations_form') || document.querySelector('.variations_form');
            const variation = variantForm?.querySelector('[name="variation_id"]');
            if (variantForm && (!variation || !Number(variation.value))) throw new Error('Choose a product variation first.');
            const body = new FormData(form);
            if (variation) body.set('variation_id', variation.value);
            const response = await fetch(form.action, {method: 'POST', body, credentials: 'same-origin'});
            const data = await response.json();
            if (!response.ok || !data?.success || !data?.data?.image) {
                throw new Error(data?.data?.message || 'Refresh the product page and check that you are still signed in.');
            }
            if (version !== photoVersion) return;
            const {image, mime} = data.data;
            if (resultUrl) URL.revokeObjectURL(resultUrl);
            const bytes = Uint8Array.from(atob(image), character => character.charCodeAt(0));
            resultUrl = URL.createObjectURL(new Blob([bytes], {type: mime}));
            result.src = resultUrl;
            download.href = resultUrl;
            download.download = 'try-on.' + (mime === 'image/jpeg' ? 'jpg' : mime.split('/')[1]);
            after.disabled = false;
            show('after');
            status.textContent = 'Your try-on image is ready.';
        } catch (error) {
            if (version === photoVersion) {
                status.textContent = error instanceof SyntaxError
                    ? 'WordPress returned an unexpected response. Check your hosting timeout or refresh and try again.'
                    : error.message;
            }
        } finally {
            button.disabled = false;
        }
    });
})();
